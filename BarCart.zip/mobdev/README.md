# BarCart
An android application to scan barcodes from products and store them in your own personal inventory / cart
